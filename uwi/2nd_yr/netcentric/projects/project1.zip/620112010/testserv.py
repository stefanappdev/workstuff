from PaillierClientSocket import PaillierClientSocket as pc
from PaillierServerSocket import PaillierServerSocket as ps
import socket

server= ps(socket.gethostname(),8000)
#server.ProcessMsgs()





